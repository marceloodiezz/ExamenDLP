package ast.type;

import ast.Locatable;
import visitor.Visitor;

import java.util.List;

public class RecordType extends AbstractType {

    private final List<RecordField> fields;

    public RecordType(List<RecordField> fields) {
        this.fields = fields;
    }

    public List<RecordField> getFields() {
        return this.fields;
    }

    public RecordField getField(String id) {
        for(RecordField f : fields)
            if(f.getName().equals(id))
                return f;
        return null;
    }

    @Override
    public <RT, PT> RT accept(Visitor<RT, PT> v, PT param) {
        return v.visit(this, param);
    }

    @Override
    public Type dot(String fieldName, Locatable l) {
        for(RecordField f : fields)
            if(f.getName().equals(fieldName))
                return f.getTargetType();
        return new ErrorType("No se ha encontrado ningún campo '" + fieldName + "' en el Record.", l);
    }

    @Override
    public String toString() {
        StringBuilder st = new StringBuilder();
        if (!fields.isEmpty()) {
            st.append("RecordType" + "[fields:");
            for (RecordField recordField : fields)
                st.append("[Field[name:" + recordField.getName() + ",type:" + recordField.getTargetType() + ",offset:" + recordField.getOffset() + "]]");
            st.append("]");
            return st.toString();
        }
        else
            return "RecordType";

    }

    @Override
    public int numberOfBytes() {
        int cont = 0;
        for(RecordField field : fields)
            cont += field.getTargetType().numberOfBytes();
        return cont;
    }

}
